import { HttpError } from 'wasp/server'

export const createPortfolio = async ({ name }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const newPortfolio = await context.entities.Portfolio.create({
    data: {
      name,
      userId: context.user.id
    }
  });

  return newPortfolio;
}

export const addStockToPortfolio = async ({ portfolioId, symbol, price }, context) => {
  if (!context.user) { throw new HttpError(401) };

  const portfolio = await context.entities.Portfolio.findUnique({
    where: { id: portfolioId }
  });
  if (!portfolio || portfolio.userId !== context.user.id) { throw new HttpError(403) };

  const newStock = await context.entities.Stock.create({
    data: {
      symbol,
      price,
      portfolioId
    }
  });

  return context.entities.Portfolio.findUnique({
    where: { id: portfolioId },
    include: { stocks: true }
  });
}
