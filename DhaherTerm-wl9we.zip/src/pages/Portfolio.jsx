import React, { useState } from 'react';
import { useParams } from 'wasp/client/router';
import { useQuery, useAction, getStockDetails, addStockToPortfolio } from 'wasp/client/operations';

const PortfolioPage = () => {
  const { portfolioId } = useParams();
  const { data: stockDetails, isLoading, error } = useQuery(getStockDetails, { symbol: '' });
  const addStockFn = useAction(addStockToPortfolio);
  const [newStockSymbol, setNewStockSymbol] = useState('');
  const [newStockPrice, setNewStockPrice] = useState('');

  if (isLoading) return 'Loading...';
  if (error) return 'Error: ' + error;

  const handleAddStock = () => {
    addStockFn({ portfolioId: parseInt(portfolioId), symbol: newStockSymbol, price: parseFloat(newStockPrice) });
    setNewStockSymbol('');
    setNewStockPrice('');
  };

  return (
    <div className='p-4'>
      <h1 className='text-2xl font-bold mb-4'>Portfolio Details</h1>
      <div className='mb-4'>
        <input
          type='text'
          placeholder='Stock Symbol'
          className='px-2 py-1 border rounded mr-2'
          value={newStockSymbol}
          onChange={(e) => setNewStockSymbol(e.target.value)}
        />
        <input
          type='number'
          placeholder='Stock Price'
          className='px-2 py-1 border rounded mr-2'
          value={newStockPrice}
          onChange={(e) => setNewStockPrice(e.target.value)}
        />
        <button
          onClick={handleAddStock}
          className='bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded'
        >
          Add Stock
        </button>
      </div>
      <div className='bg-gray-100 p-4 rounded-lg'>
        {stockDetails ? (
          <div>
            <h2 className='text-xl font-semibold'>Stock Details</h2>
            <p>Symbol: {stockDetails.symbol}</p>
            <p>Price: {stockDetails.price}</p>
          </div>
        ) : (
          <p>No stock details available.</p>
        )}
      </div>
    </div>
  );
};

export default PortfolioPage;
