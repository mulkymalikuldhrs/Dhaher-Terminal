import { HttpError } from 'wasp/server'

export const getUserPortfolios = async (args, context) => {
  if (!context.user) { throw new HttpError(401) }
  return context.entities.Portfolio.findMany({
    where: { userId: context.user.id },
    include: { stocks: true }
  });
}

export const getStockDetails = async ({ symbol }, context) => {
  if (!context.user) { throw new HttpError(401) }

  const stock = await context.entities.Stock.findUnique({
    where: { symbol },
    select: {
      id: true,
      symbol: true,
      price: true
    }
  });

  if (!stock) throw new HttpError(404, 'No stock with symbol ' + symbol);

  return stock;
}
