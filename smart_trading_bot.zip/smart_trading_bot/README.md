# Smart Trading Bot - AI Trading Otomatis Cerdas

Bot trading otomatis yang menggunakan analisis teknikal SMC/ICT, machine learning, dan integrasi dengan MetaTrader untuk trading yang cerdas dan otomatis.

## Fitur Utama

### 🤖 AI & Machine Learning
- Analisis teknikal otomatis menggunakan SMC/ICT
- Prediksi pergerakan harga dengan neural networks
- Pembelajaran dari history trading untuk optimisasi
- Sentiment analysis dari berita dan media sosial

### 📊 Analisis Teknikal Canggih
- Smart Money Concept (SMC) analysis
- Inner Circle Trader (ICT) methodology
- Multi-timeframe analysis (H4 → M15 → M5)
- Order Blocks, Fair Value Gaps, Breaker Blocks detection
- Liquidity sweep identification
- Change of Character (CHOCH) dan Market Structure Shift (MSS)

### 💰 Trading Otomatis
- Eksekusi order otomatis berdasarkan sinyal
- Manajemen risk otomatis (2% per trade)
- Stop loss dan take profit otomatis
- Position sizing berdasarkan account balance
- Trailing stop untuk maksimalisasi profit

### 🔗 Integrasi Platform
- MetaTrader 4/5 integration
- Broker API support (OANDA, Alpaca, dll)
- TradingView webhook integration
- Real-time data feeds

### 📱 Monitoring & Notifikasi
- Dashboard web real-time
- Notifikasi Telegram/WhatsApp
- Performance tracking
- Trade journal otomatis

## Struktur Proyek

```
smart_trading_bot/
├── core/                   # Core engine dan orchestrator
├── analysis/              # Analisis teknikal dan fundamental
├── strategies/            # Strategi trading (SMC/ICT)
├── risk_management/       # Manajemen risk dan money management
├── brokers/              # Integrasi dengan broker dan platform
├── ml_models/            # Model machine learning
├── data/                 # Data market dan historical
├── config/               # Konfigurasi dan settings
├── logs/                 # Log files
└── tests/                # Unit tests
```

## Instalasi dan Setup

1. Clone repository
2. Install dependencies: `pip install -r requirements.txt`
3. Setup konfigurasi di `config/settings.yaml`
4. Jalankan bot: `python main.py`

## Konfigurasi

Bot dapat dikonfigurasi untuk:
- Pair trading yang diinginkan (GBP/USD, EUR/USD, XAUUSD, dll)
- Risk management settings
- Timeframe analysis
- Broker credentials
- Notification settings

## Keamanan

- Enkripsi credentials
- Secure API connections
- Risk limits dan safety stops
- Audit trail lengkap

