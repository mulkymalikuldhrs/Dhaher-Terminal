"""
Smart Trading Bot - Market Data Fetcher
Fetches historical and real-time market data from various sources.
"""

import pandas as pd
import asyncio
import logging
from typing import Dict, Any, List

from core.logger_setup import BotLogger
from brokers.metatrader_connector import MetaTraderConnector
# from brokers.oanda_connector import OANDAConnector

class MarketDataFetcher:
    """Fetches market data from configured brokers/data sources."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = BotLogger(__name__)
        self.brokers_config = config["brokers"]
        self.trading_config = config["trading"]
        
        self.connectors = []
        self._initialize_connectors()
        
        self.logger.info("Market Data Fetcher initialized.")

    def _initialize_connectors(self):
        """Initializes broker connectors based on configuration."""
        if self.brokers_config.get("metatrader", {}).get("enabled", False):
            self.connectors.append(MetaTraderConnector(self.config))
            self.logger.info("MetaTrader connector enabled.")
        
        if self.brokers_config.get("oanda", {}).get("enabled", False):
            # self.connectors.append(OANDAConnector(self.config))
            self.logger.info("OANDA connector enabled (placeholder).")
        
        if not self.connectors:
            self.logger.warning("No market data connectors enabled. Bot will not fetch real data.")

    async def fetch_data(self) -> Dict[str, pd.DataFrame]:
        """Fetches market data for configured pairs and timeframes."""
        market_data = {}
        pairs = self.trading_config["pairs"]
        timeframes = list(self.trading_config["timeframes"].values())
        
        for connector in self.connectors:
            if not connector.connected:
                await connector.connect()
            for pair in pairs:
                for tf in timeframes:
                    try:
                        data = await connector.get_historical_data(pair, tf, 100) # Fetch 100 candles
                        if not data.empty:
                            if tf not in market_data:
                                market_data[tf] = pd.DataFrame()
                            market_data[tf] = pd.concat([market_data[tf], data])
                            self.logger.info(f"Fetched real data for {pair} on {tf}.")
                        else:
                            self.logger.warning(f"No data returned for {pair} on {tf} from {connector.__class__.__name__}.")
                    except Exception as e:
                        self.logger.error(f"Failed to fetch data for {pair} on {tf} from {connector.__class__.__name__}: {e}")
        
        # Ensure data is properly indexed and sorted if multiple pairs/TFs are combined
        for tf, df in market_data.items():
            if not df.empty:
                market_data[tf] = df.sort_values(by="time").set_index("time")
        
        self.logger.info("Market data fetching completed.")
        return market_data

    def _generate_mock_data(self, symbol: str, timeframe: str, num_candles: int = 100) -> pd.DataFrame:
        """Generates mock OHLCV data for testing purposes."""
        # This function is no longer primarily used if real connectors are enabled
        data = {
            "time": pd.to_datetime(pd.date_range(end=pd.Timestamp.now(), periods=num_candles, freq=timeframe)),
            "open": np.random.rand(num_candles) * 100 + 1000,
            "high": np.random.rand(num_candles) * 10 + 1095,
            "low": np.random.rand(num_candles) * 10 + 1000,
            "close": np.random.rand(num_candles) * 100 + 1000,
            "volume": np.random.randint(100, 1000, num_candles)
        }
        # Ensure high >= open, close, low and low <= open, close, high
        data["high"] = np.maximum(data["high"], np.maximum(data["open"], data["close"]))
        data["low"] = np.minimum(data["low"], np.minimum(data["open"], data["close"]))
        
        df = pd.DataFrame(data)
        df["symbol"] = symbol
        return df


