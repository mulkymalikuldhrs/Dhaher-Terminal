"""
Smart Trading Bot - Broker Connector Base Class
Defines the interface for all broker integrations.
"""

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import Dict, Any, List, Optional
import pandas as pd # Added for pd.DataFrame type hint

from core.logger_setup import BotLogger

class BrokerConnector(ABC):
    """Abstract base class for all broker connectors."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = BotLogger(self.__class__.__name__)
        self.connected = False
        
    @abstractmethod
    async def connect(self) -> bool:
        """Establishes connection to the broker."""
        pass

    @abstractmethod
    async def disconnect(self):
        """Closes connection to the broker.""" 
        pass

    @abstractmethod
    async def get_account_info(self) -> Dict[str, Any]:
        """Retrieves account information (balance, equity, etc.)."""
        pass

    @abstractmethod
    async def get_open_positions(self) -> List[Dict[str, Any]]:
        """Retrieves all open trading positions."""
        pass

    @abstractmethod
    async def get_historical_data(self, symbol: str, timeframe: str, count: int) -> pd.DataFrame:
        """Fetches historical OHLCV data for a given symbol and timeframe."""
        pass

    @abstractmethod
    async def place_order(self, symbol: str, order_type: str, direction: str, volume: float, 
                          price: Optional[float] = None, stop_loss: Optional[float] = None, 
                          take_profit: Optional[float] = None) -> Dict[str, Any]:
        """Places a new trading order."""
        pass

    @abstractmethod
    async def modify_order(self, order_id: str, new_stop_loss: Optional[float] = None, 
                           new_take_profit: Optional[float] = None) -> Dict[str, Any]:
        """Modifies an existing order (e.g., SL/TP)."""
        pass

    @abstractmethod
    async def close_position(self, position_id: str) -> Dict[str, Any]:
        """Closes an open trading position."""
        pass

    @abstractmethod
    async def get_current_price(self, symbol: str) -> Dict[str, float]:
        """Fetches the current bid/ask price for a symbol."""
        pass


