"""
Smart Trading Bot - Broker Manager
Manages multiple broker connections and provides unified interface.
"""

import asyncio
import logging
from typing import Dict, Any, List, Optional

from core.logger_setup import BotLogger
from brokers.broker_connector import BrokerConnector
from brokers.metatrader_connector import MetaTraderConnector
from brokers.oanda_connector import OANDAConnector

class BrokerManager:
    """Manages multiple broker connections and provides unified interface."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = BotLogger(__name__)
        self.brokers_config = config["brokers"]
        
        self.connectors: Dict[str, BrokerConnector] = {}
        self.primary_broker = None
        
        self._initialize_brokers()
        
        self.logger.info("Broker Manager initialized.")

    def _initialize_brokers(self):
        """Initializes all configured broker connectors."""
        if self.brokers_config.get("metatrader", {}).get("enabled", False):
            self.connectors["metatrader"] = MetaTraderConnector(self.config)
            if not self.primary_broker:
                self.primary_broker = "metatrader"
            self.logger.info("MetaTrader connector initialized.")
        
        if self.brokers_config.get("oanda", {}).get("enabled", False):
            self.connectors["oanda"] = OANDAConnector(self.config)
            if not self.primary_broker:
                self.primary_broker = "oanda"
            self.logger.info("OANDA connector initialized.")
        
        if not self.connectors:
            self.logger.warning("No broker connectors configured.")

    async def connect_all(self) -> Dict[str, bool]:
        """Connects to all configured brokers."""
        connection_results = {}
        
        for broker_name, connector in self.connectors.items():
            try:
                result = await connector.connect()
                connection_results[broker_name] = result
                if result:
                    self.logger.info(f"Successfully connected to {broker_name}.")
                else:
                    self.logger.error(f"Failed to connect to {broker_name}.")
            except Exception as e:
                self.logger.error(f"Error connecting to {broker_name}: {e}")
                connection_results[broker_name] = False
        
        return connection_results

    async def disconnect_all(self):
        """Disconnects from all brokers."""
        for broker_name, connector in self.connectors.items():
            try:
                await connector.disconnect()
                self.logger.info(f"Disconnected from {broker_name}.")
            except Exception as e:
                self.logger.error(f"Error disconnecting from {broker_name}: {e}")

    async def execute_trades(self, trade_signals: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """Executes trade signals using the primary broker."""
        execution_results = []
        
        if not self.primary_broker or self.primary_broker not in self.connectors:
            self.logger.error("No primary broker available for trade execution.")
            return execution_results
        
        primary_connector = self.connectors[self.primary_broker]
        
        if not primary_connector.connected:
            self.logger.warning(f"Primary broker {self.primary_broker} not connected. Attempting to reconnect...")
            await primary_connector.connect()
        
        for signal in trade_signals:
            try:
                result = await self._execute_single_trade(primary_connector, signal)
                execution_results.append(result)
                self.logger.info(f"Trade executed: {result}")
            except Exception as e:
                self.logger.error(f"Failed to execute trade {signal}: {e}")
                execution_results.append({
                    "status": "error",
                    "signal": signal,
                    "error": str(e)
                })
        
        return execution_results

    async def _execute_single_trade(self, connector: BrokerConnector, signal: Dict[str, Any]) -> Dict[str, Any]:
        """Executes a single trade signal."""
        symbol = signal["symbol"]
        direction = signal["direction"]
        volume = signal["position_size"]
        entry_price = signal.get("entry_price")
        stop_loss = signal.get("stop_loss")
        take_profit = signal.get("take_profit")
        
        # Place the order
        result = await connector.place_order(
            symbol=symbol,
            order_type="MARKET",  # Assuming market orders for now
            direction=direction,
            volume=volume,
            price=entry_price,
            stop_loss=stop_loss,
            take_profit=take_profit
        )
        
        return {
            "status": result.get("status", "unknown"),
            "signal": signal,
            "broker_result": result
        }

    async def get_account_info(self, broker_name: Optional[str] = None) -> Dict[str, Any]:
        """Gets account information from specified broker or primary broker."""
        target_broker = broker_name or self.primary_broker
        
        if target_broker not in self.connectors:
            self.logger.error(f"Broker {target_broker} not found.")
            return {}
        
        connector = self.connectors[target_broker]
        return await connector.get_account_info()

    async def get_open_positions(self, broker_name: Optional[str] = None) -> List[Dict[str, Any]]:
        """Gets open positions from specified broker or primary broker."""
        target_broker = broker_name or self.primary_broker
        
        if target_broker not in self.connectors:
            self.logger.error(f"Broker {target_broker} not found.")
            return []
        
        connector = self.connectors[target_broker]
        return await connector.get_open_positions()

    async def get_historical_data(self, symbol: str, timeframe: str, count: int, 
                                  broker_name: Optional[str] = None) -> pd.DataFrame:
        """Gets historical data from specified broker or primary broker."""
        target_broker = broker_name or self.primary_broker
        
        if target_broker not in self.connectors:
            self.logger.error(f"Broker {target_broker} not found.")
            return pd.DataFrame()
        
        connector = self.connectors[target_broker]
        return await connector.get_historical_data(symbol, timeframe, count)

    async def monitor_positions(self) -> Dict[str, Any]:
        """Monitors all open positions across all connected brokers."""
        all_positions = {}
        
        for broker_name, connector in self.connectors.items():
            if connector.connected:
                try:
                    positions = await connector.get_open_positions()
                    all_positions[broker_name] = positions
                except Exception as e:
                    self.logger.error(f"Error getting positions from {broker_name}: {e}")
                    all_positions[broker_name] = []
        
        return all_positions

    async def close_position(self, position_id: str, broker_name: Optional[str] = None) -> Dict[str, Any]:
        """Closes a specific position."""
        target_broker = broker_name or self.primary_broker
        
        if target_broker not in self.connectors:
            self.logger.error(f"Broker {target_broker} not found.")
            return {"status": "error", "message": "Broker not found"}
        
        connector = self.connectors[target_broker]
        return await connector.close_position(position_id)

    def get_broker_status(self) -> Dict[str, bool]:
        """Returns connection status of all brokers."""
        return {name: connector.connected for name, connector in self.connectors.items()}

