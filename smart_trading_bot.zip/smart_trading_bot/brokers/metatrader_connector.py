"""
Smart Trading Bot - MetaTrader Connector
Connects to MetaTrader 5 (MT5) via MetaTrader for Python API.
"""

import asyncio
import logging
import pandas as pd
from typing import Dict, Any, List, Optional

from core.logger_setup import BotLogger
from brokers.broker_connector import BrokerConnector

# Import MetaTrader5 library (assuming it's installed in the environment where the bot runs)
# try:
#     import MetaTrader5 as mt5
# except ImportError:
#     print("MetaTrader5 library not found. Please install it: pip install MetaTrader5")
#     mt5 = None

class MetaTraderConnector(BrokerConnector):
    """Connects to MetaTrader 5 (MT5) and handles trading operations."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.mt5_config = config["brokers"]["metatrader"]
        self.login = self.mt5_config["login"]
        self.password = self.mt5_config["password"]
        self.server = self.mt5_config["server"]
        self.path = self.mt5_config["path"] # Path to MetaTrader terminal.exe
        
        self.logger.info("MetaTrader Connector initialized.")

    async def connect(self) -> bool:
        """Establishes connection to MT5."""
        if not mt5:
            self.logger.error("MetaTrader5 library not loaded. Cannot connect.")
            return False

        if not mt5.initialize(path=self.path):
            self.logger.error(f"MT5 initialize() failed, error code = {mt5.last_error()}")
            return False

        authorized = mt5.login(self.login, password=self.password, server=self.server)
        if not authorized:
            self.logger.error(f"MT5 connect() failed, error code = {mt5.last_error()}")
            mt5.shutdown()
            return False

        self.connected = True
        self.logger.info("Connected to MetaTrader 5 successfully.")
        return True

    async def disconnect(self):
        """Closes connection to MT5."""
        if self.connected and mt5:
            mt5.shutdown()
            self.connected = False
            self.logger.info("Disconnected from MetaTrader 5.")

    async def get_account_info(self) -> Dict[str, Any]:
        """Retrieves account information."""
        if not self.connected or not mt5:
            self.logger.warning("Not connected to MT5. Cannot get account info.")
            return {}
        
        account_info = mt5.account_info()
        if account_info:
            return account_info._asdict()
        else:
            self.logger.error(f"Failed to get account info: {mt5.last_error()}")
            return {}

    async def get_open_positions(self) -> List[Dict[str, Any]]:
        """Retrieves all open trading positions."""
        if not self.connected or not mt5:
            self.logger.warning("Not connected to MT5. Cannot get open positions.")
            return []
        
        positions = mt5.positions_get()
        if positions:
            return [pos._asdict() for pos in positions]
        else:
            self.logger.info("No open positions found.")
            return []

    async def get_historical_data(self, symbol: str, timeframe: str, count: int) -> pd.DataFrame:
        """Fetches historical OHLCV data."""
        if not self.connected or not mt5:
            self.logger.warning("Not connected to MT5. Cannot get historical data.")
            return pd.DataFrame()
        
        # Convert string timeframe to mt5.TIMEFRAME_ constant
        mt5_timeframe = getattr(mt5, f"TIMEFRAME_{timeframe.upper()}", None)
        if not mt5_timeframe:
            self.logger.error(f"Invalid timeframe: {timeframe}")
            return pd.DataFrame()

        rates = mt5.copy_rates_from_pos(symbol, mt5_timeframe, 0, count)
        if rates is None:
            self.logger.error(f"Failed to get historical data for {symbol} {timeframe}: {mt5.last_error()}")
            return pd.DataFrame()
        
        df = pd.DataFrame(rates)
        df["time"] = pd.to_datetime(df["time"], unit="s")
        df.set_index("time", inplace=True)
        return df

    async def place_order(self, symbol: str, order_type: str, direction: str, volume: float, 
                          price: Optional[float] = None, stop_loss: Optional[float] = None, 
                          take_profit: Optional[float] = None) -> Dict[str, Any]:
        """Places a new trading order."""
        if not self.connected or not mt5:
            self.logger.warning("Not connected to MT5. Cannot place order.")
            return {"status": "error", "message": "Not connected to MT5"}

        # Define request parameters
        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": symbol,
            "volume": volume,
            "type": mt5.ORDER_TYPE_BUY if direction == "BUY" else mt5.ORDER_TYPE_SELL,
            "price": price if price else mt5.symbol_info_tick(symbol).ask if direction == "BUY" else mt5.symbol_info_tick(symbol).bid,
            "sl": stop_loss if stop_loss else 0.0,
            "tp": take_profit if take_profit else 0.0,
            "deviation": 20, # Slippage in points
            "magic": 20250614, # Unique ID for bot orders
            "comment": "SmartTradingBot Order",
            "type_time": mt5.ORDER_TIME_GTC, # Good till cancel
            "type_filling": mt5.ORDER_FILLING_FOC, # Fill or Kill
        }

        # Send order
        result = mt5.order_send(request)
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            self.logger.error(f"Order send failed: {result.comment}, retcode={result.retcode}")
            return {"status": "error", "message": result.comment, "retcode": result.retcode}
        else:
            self.logger.info(f"Order placed successfully: {result.order}")
            return {"status": "success", "order_id": result.order, "deal_id": result.deal}

    async def modify_order(self, order_id: str, new_stop_loss: Optional[float] = None, 
                           new_take_profit: Optional[float] = None) -> Dict[str, Any]:
        """Modifies an existing order."""
        if not self.connected or not mt5:
            self.logger.warning("Not connected to MT5. Cannot modify order.")
            return {"status": "error", "message": "Not connected to MT5"}

        # Get current position info to modify SL/TP
        position = mt5.positions_get(ticket=order_id)
        if not position:
            self.logger.error(f"Position {order_id} not found.")
            return {"status": "error", "message": "Position not found"}
        
        position = position[0]

        request = {
            "action": mt5.TRADE_ACTION_SLTP,
            "position": position.ticket,
            "sl": new_stop_loss if new_stop_loss else position.sl,
            "tp": new_take_profit if new_take_profit else position.tp,
            "deviation": 20,
            "magic": 20250614,
            "comment": "SmartTradingBot Modify Order",
        }

        result = mt5.order_send(request)
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            self.logger.error(f"Order modify failed: {result.comment}, retcode={result.retcode}")
            return {"status": "error", "message": result.comment, "retcode": result.retcode}
        else:
            self.logger.info(f"Order {order_id} modified successfully.")
            return {"status": "success", "order_id": result.order, "deal_id": result.deal}

    async def close_position(self, position_id: str) -> Dict[str, Any]:
        """Closes an open trading position."""
        if not self.connected or not mt5:
            self.logger.warning("Not connected to MT5. Cannot close position.")
            return {"status": "error", "message": "Not connected to MT5"}

        position = mt5.positions_get(ticket=position_id)
        if not position:
            self.logger.error(f"Position {position_id} not found.")
            return {"status": "error", "message": "Position not found"}
        
        position = position[0]

        request = {
            "action": mt5.TRADE_ACTION_DEAL,
            "symbol": position.symbol,
            "volume": position.volume,
            "type": mt5.ORDER_TYPE_SELL if position.type == mt5.ORDER_TYPE_BUY else mt5.ORDER_TYPE_BUY,
            "price": mt5.symbol_info_tick(position.symbol).bid if position.type == mt5.ORDER_TYPE_BUY else mt5.symbol_info_tick(position.symbol).ask,
            "deviation": 20,
            "magic": 20250614,
            "comment": "SmartTradingBot Close Position",
            "position": position.ticket,
        }

        result = mt5.order_send(request)
        if result.retcode != mt5.TRADE_RETCODE_DONE:
            self.logger.error(f"Position close failed: {result.comment}, retcode={result.retcode}")
            return {"status": "error", "message": result.comment, "retcode": result.retcode}
        else:
            self.logger.info(f"Position {position_id} closed successfully.")
            return {"status": "success", "order_id": result.order, "deal_id": result.deal}

    async def get_current_price(self, symbol: str) -> Dict[str, float]:
        """Fetches the current bid/ask price for a symbol."""
        if not self.connected or not mt5:
            self.logger.warning("Not connected to MT5. Cannot get current price.")
            return {}
        
        tick = mt5.symbol_info_tick(symbol)
        if tick:
            return {"bid": tick.bid, "ask": tick.ask}
        else:
            self.logger.error(f"Failed to get tick info for {symbol}: {mt5.last_error()}")
            return {}


