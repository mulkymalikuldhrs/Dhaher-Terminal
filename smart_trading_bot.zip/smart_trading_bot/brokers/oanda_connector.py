"""
Smart Trading Bot - OANDA Connector
Connects to OANDA broker via REST API.
"""

import asyncio
import logging
import pandas as pd
import aiohttp
from typing import Dict, Any, List, Optional

from core.logger_setup import BotLogger
from brokers.broker_connector import BrokerConnector

class OANDAConnector(BrokerConnector):
    """Connects to OANDA broker via REST API."""
    
    def __init__(self, config: Dict[str, Any]):
        super().__init__(config)
        self.oanda_config = config["brokers"]["oanda"]
        self.account_id = self.oanda_config["account_id"]
        self.access_token = self.oanda_config["access_token"]
        self.api_url = "https://api-fxtrade.oanda.com"  # Live
        # self.api_url = "https://api-fxpractice.oanda.com"  # Demo
        
        self.session = None
        self.headers = {
            "Authorization": f"Bearer {self.access_token}",
            "Content-Type": "application/json"
        }
        
        self.logger.info("OANDA Connector initialized.")

    async def connect(self) -> bool:
        """Establishes connection to OANDA."""
        try:
            self.session = aiohttp.ClientSession(headers=self.headers)
            
            # Test connection by getting account info
            async with self.session.get(f"{self.api_url}/v3/accounts/{self.account_id}") as response:
                if response.status == 200:
                    self.connected = True
                    self.logger.info("Connected to OANDA successfully.")
                    return True
                else:
                    self.logger.error(f"OANDA connection failed: {response.status} - {await response.text()}")
                    return False
        except Exception as e:
            self.logger.error(f"Error connecting to OANDA: {e}")
            return False

    async def disconnect(self):
        """Closes connection to OANDA."""
        if self.session:
            await self.session.close()
            self.connected = False
            self.logger.info("Disconnected from OANDA.")

    async def get_account_info(self) -> Dict[str, Any]:
        """Retrieves account information."""
        if not self.connected or not self.session:
            self.logger.warning("Not connected to OANDA. Cannot get account info.")
            return {}
        
        try:
            async with self.session.get(f"{self.api_url}/v3/accounts/{self.account_id}") as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("account", {})
                else:
                    self.logger.error(f"Failed to get account info: {response.status}")
                    return {}
        except Exception as e:
            self.logger.error(f"Error getting account info: {e}")
            return {}

    async def get_open_positions(self) -> List[Dict[str, Any]]:
        """Retrieves all open trading positions."""
        if not self.connected or not self.session:
            self.logger.warning("Not connected to OANDA. Cannot get open positions.")
            return []
        
        try:
            async with self.session.get(f"{self.api_url}/v3/accounts/{self.account_id}/openPositions") as response:
                if response.status == 200:
                    data = await response.json()
                    return data.get("positions", [])
                else:
                    self.logger.error(f"Failed to get open positions: {response.status}")
                    return []
        except Exception as e:
            self.logger.error(f"Error getting open positions: {e}")
            return []

    async def get_historical_data(self, symbol: str, timeframe: str, count: int) -> pd.DataFrame:
        """Fetches historical OHLCV data."""
        if not self.connected or not self.session:
            self.logger.warning("Not connected to OANDA. Cannot get historical data.")
            return pd.DataFrame()
        
        # Convert timeframe to OANDA format
        oanda_timeframe = self._convert_timeframe(timeframe)
        
        try:
            params = {
                "granularity": oanda_timeframe,
                "count": count
            }
            
            async with self.session.get(f"{self.api_url}/v3/instruments/{symbol}/candles", params=params) as response:
                if response.status == 200:
                    data = await response.json()
                    candles = data.get("candles", [])
                    
                    # Convert to DataFrame
                    df_data = []
                    for candle in candles:
                        if candle["complete"]:
                            df_data.append({
                                "time": pd.to_datetime(candle["time"]),
                                "open": float(candle["mid"]["o"]),
                                "high": float(candle["mid"]["h"]),
                                "low": float(candle["mid"]["l"]),
                                "close": float(candle["mid"]["c"]),
                                "volume": int(candle["volume"])
                            })
                    
                    df = pd.DataFrame(df_data)
                    if not df.empty:
                        df.set_index("time", inplace=True)
                    return df
                else:
                    self.logger.error(f"Failed to get historical data: {response.status}")
                    return pd.DataFrame()
        except Exception as e:
            self.logger.error(f"Error getting historical data: {e}")
            return pd.DataFrame()

    def _convert_timeframe(self, timeframe: str) -> str:
        """Converts standard timeframe to OANDA format."""
        timeframe_map = {
            "M1": "M1",
            "M5": "M5",
            "M15": "M15",
            "M30": "M30",
            "H1": "H1",
            "H4": "H4",
            "D1": "D",
            "W1": "W",
            "MN1": "M"
        }
        return timeframe_map.get(timeframe, "H1")

    async def place_order(self, symbol: str, order_type: str, direction: str, volume: float, 
                          price: Optional[float] = None, stop_loss: Optional[float] = None, 
                          take_profit: Optional[float] = None) -> Dict[str, Any]:
        """Places a new trading order."""
        if not self.connected or not self.session:
            self.logger.warning("Not connected to OANDA. Cannot place order.")
            return {"status": "error", "message": "Not connected to OANDA"}

        try:
            order_data = {
                "order": {
                    "type": "MARKET",
                    "instrument": symbol,
                    "units": str(int(volume * 10000)) if direction == "BUY" else str(-int(volume * 10000)),  # Convert to units
                    "timeInForce": "FOK",
                    "positionFill": "DEFAULT"
                }
            }
            
            # Add stop loss and take profit if provided
            if stop_loss:
                order_data["order"]["stopLossOnFill"] = {"price": str(stop_loss)}
            if take_profit:
                order_data["order"]["takeProfitOnFill"] = {"price": str(take_profit)}

            async with self.session.post(f"{self.api_url}/v3/accounts/{self.account_id}/orders", json=order_data) as response:
                if response.status == 201:
                    data = await response.json()
                    return {"status": "success", "order_data": data}
                else:
                    error_text = await response.text()
                    self.logger.error(f"Order placement failed: {response.status} - {error_text}")
                    return {"status": "error", "message": error_text}
        except Exception as e:
            self.logger.error(f"Error placing order: {e}")
            return {"status": "error", "message": str(e)}

    async def modify_order(self, order_id: str, new_stop_loss: Optional[float] = None, 
                           new_take_profit: Optional[float] = None) -> Dict[str, Any]:
        """Modifies an existing order."""
        # OANDA doesn't modify orders directly, but modifies positions
        # This is a placeholder implementation
        self.logger.warning("Order modification not fully implemented for OANDA.")
        return {"status": "error", "message": "Not implemented"}

    async def close_position(self, position_id: str) -> Dict[str, Any]:
        """Closes an open trading position."""
        if not self.connected or not self.session:
            self.logger.warning("Not connected to OANDA. Cannot close position.")
            return {"status": "error", "message": "Not connected to OANDA"}

        try:
            # For OANDA, position_id is the instrument name
            close_data = {"longUnits": "ALL"} if position_id.endswith("_long") else {"shortUnits": "ALL"}
            instrument = position_id.replace("_long", "").replace("_short", "")
            
            async with self.session.put(f"{self.api_url}/v3/accounts/{self.account_id}/positions/{instrument}/close", json=close_data) as response:
                if response.status == 200:
                    data = await response.json()
                    return {"status": "success", "close_data": data}
                else:
                    error_text = await response.text()
                    self.logger.error(f"Position close failed: {response.status} - {error_text}")
                    return {"status": "error", "message": error_text}
        except Exception as e:
            self.logger.error(f"Error closing position: {e}")
            return {"status": "error", "message": str(e)}

    async def get_current_price(self, symbol: str) -> Dict[str, float]:
        """Fetches the current bid/ask price for a symbol."""
        if not self.connected or not self.session:
            self.logger.warning("Not connected to OANDA. Cannot get current price.")
            return {}
        
        try:
            async with self.session.get(f"{self.api_url}/v3/accounts/{self.account_id}/pricing", params={"instruments": symbol}) as response:
                if response.status == 200:
                    data = await response.json()
                    prices = data.get("prices", [])
                    if prices:
                        price_data = prices[0]
                        return {
                            "bid": float(price_data["bids"][0]["price"]),
                            "ask": float(price_data["asks"][0]["price"])
                        }
                    return {}
                else:
                    self.logger.error(f"Failed to get current price: {response.status}")
                    return {}
        except Exception as e:
            self.logger.error(f"Error getting current price: {e}")
            return {}

