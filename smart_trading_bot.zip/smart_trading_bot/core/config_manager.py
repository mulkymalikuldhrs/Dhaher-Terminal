"""
Smart Trading Bot - Core Configuration Manager
Handles loading, saving, and managing bot configurations.
"""

import os
import yaml
import logging
from pathlib import Path
from typing import Dict, Any, Optional
from cryptography.fernet import Fernet

class ConfigManager:
    """Manages configuration for the Smart Trading Bot."""
    
    def __init__(self, config_dir: Optional[str] = None):
        self.logger = logging.getLogger(__name__)
        self.config_dir = Path(config_dir) if config_dir else Path(__file__).parent.parent / "config"
        self.config_file = self.config_dir / "settings.yaml"
        self.secrets_file = self.config_dir / "secrets.enc"
        self.key_file = self.config_dir / ".key"
        
        # Ensure config directory exists
        self.config_dir.mkdir(exist_ok=True)
        
        # Initialize encryption key
        self._init_encryption_key()
    
    def _init_encryption_key(self):
        """Initialize or load encryption key for secrets."""
        if not self.key_file.exists():
            key = Fernet.generate_key()
            with open(self.key_file, "wb") as f:
                f.write(key)
            os.chmod(self.key_file, 0o600)  # Restrict permissions
        
        with open(self.key_file, "rb") as f:
            self.encryption_key = f.read()
        
        self.cipher = Fernet(self.encryption_key)
    
    async def load_config(self) -> Dict[str, Any]:
        """Load configuration from file or create default."""
        if self.config_file.exists():
            with open(self.config_file, "r") as f:
                config = yaml.safe_load(f)
        else:
            config = self._create_default_config()
            await self.save_config(config)
        
        # Load secrets
        secrets = await self._load_secrets()
        config["secrets"] = secrets
        
        return config
    
    async def save_config(self, config: Dict[str, Any]):
        """Save configuration to file."""
        # Separate secrets from main config
        config_copy = config.copy()
        secrets = config_copy.pop("secrets", {})
        
        # Save main config
        with open(self.config_file, "w") as f:
            yaml.dump(config_copy, f, default_flow_style=False)
        
        # Save secrets separately
        await self._save_secrets(secrets)
    
    async def _load_secrets(self) -> Dict[str, str]:
        """Load encrypted secrets."""
        if not self.secrets_file.exists():
            return {}
        
        try:
            with open(self.secrets_file, "rb") as f:
                encrypted_data = f.read()
            
            decrypted_data = self.cipher.decrypt(encrypted_data)
            return json.loads(decrypted_data.decode())
        except Exception as e:
            self.logger.error(f"Failed to load secrets: {e}")
            return {}
    
    async def _save_secrets(self, secrets: Dict[str, str]):
        """Save encrypted secrets."""
        try:
            data = json.dumps(secrets).encode()
            encrypted_data = self.cipher.encrypt(data)
            
            with open(self.secrets_file, "wb") as f:
                f.write(encrypted_data)
            
            os.chmod(self.secrets_file, 0o600)  # Restrict permissions
        except Exception as e:
            self.logger.error(f"Failed to save secrets: {e}")
    
    def _create_default_config(self) -> Dict[str, Any]:
        """Create default configuration."""
        return {
            "bot": {
                "name": "Smart Trading Bot",
                "version": "1.0.0",
                "debug": False,
                "loop_interval": 60, # seconds
            },
            "trading": {
                "enabled": True,
                "pairs": ["EURUSD", "GBPUSD", "XAUUSD"],
                "timeframes": {
                    "HTF": "H4",
                    "MTF": "H1",
                    "LTF": "M5"
                },
                "strategy": "SMC_ICT",
                "auto_trade": False,
                "paper_trading": True,
            },
            "risk_management": {
                "enabled": True,
                "risk_per_trade_percent": 1.0,
                "max_daily_loss_percent": 4.0,
                "min_rr_ratio": 3.0,
                "max_open_trades": 5,
            },
            "brokers": {
                "metatrader": {
                    "enabled": True,
                    "path": "", # Path to MetaTrader terminal.exe
                    "login": "",
                    "password": "",
                    "server": "",
                },
                "oanda": {
                    "enabled": False,
                    "account_id": "",
                    "access_token": "",
                },
            },
            "notifications": {
                "telegram": {
                    "enabled": False,
                    "bot_token": "",
                    "chat_id": "",
                },
            },
            "logging": {
                "level": "INFO",
                "file_rotation": True,
                "max_file_size": "10MB",
                "backup_count": 5,
            },
            "secrets": {
                "telegram_api_key": os.environ.get("TELEGRAM_API_KEY", ""),
            }
        }
    
    async def get(self, key: str, default: Any = None) -> Any:
        """Get configuration value by key (supports dot notation)."""
        config = await self.load_config()
        keys = key.split(".")
        value = config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    async def set(self, key: str, value: Any):
        """Set configuration value by key (supports dot notation)."""
        config = await self.load_config()
        keys = key.split(".")
        current = config
        
        for k in keys[:-1]:
            if k not in current:
                current[k] = {}
            current = current[k]
        
        current[keys[-1]] = value
        await self.save_config(config)
    
    async def update_secret(self, key: str, value: str):
        """Update a secret value."""
        config = await self.load_config()
        config["secrets"][key] = value
        await self.save_config(config)

