"""
Smart Trading Bot - Logger Setup
Provides comprehensive logging functionality for the bot.
"""

import logging
import logging.handlers
import os
from pathlib import Path
from typing import Optional

def setup_logging(
    log_level: str = "INFO",
    log_dir: Optional[str] = None,
    max_file_size: str = "10MB",
    backup_count: int = 5
):
    """Setup logging configuration for the bot."""
    
    # Convert string log level to logging constant
    numeric_level = getattr(logging, log_level.upper(), logging.INFO)
    
    # Determine log directory
    if log_dir is None:
        log_dir = Path(__file__).parent.parent / "logs"
    else:
        log_dir = Path(log_dir)
    
    # Create log directory if it doesn't exist
    log_dir.mkdir(exist_ok=True)
    
    # Convert max_file_size to bytes
    size_multipliers = {"KB": 1024, "MB": 1024**2, "GB": 1024**3}
    size_str = max_file_size.upper()
    
    for suffix, multiplier in size_multipliers.items():
        if size_str.endswith(suffix):
            max_bytes = int(size_str[:-len(suffix)]) * multiplier
            break
    else:
        max_bytes = 10 * 1024 * 1024  # Default 10MB
    
    # Create formatters
    detailed_formatter = logging.Formatter(
        "%(asctime)s - %(name)s - %(levelname)s - %(filename)s:%(lineno)d - %(message)s"
    )
    
    simple_formatter = logging.Formatter(
        "%(asctime)s - %(levelname)s - %(message)s"
    )
    
    # Configure root logger
    root_logger = logging.getLogger()
    root_logger.setLevel(numeric_level)
    
    # Clear existing handlers
    root_logger.handlers.clear()
    
    # Console handler
    console_handler = logging.StreamHandler()
    console_handler.setLevel(numeric_level)
    console_handler.setFormatter(simple_formatter)
    root_logger.addHandler(console_handler)
    
    # File handler with rotation
    log_file = log_dir / "smart_trading_bot.log"
    file_handler = logging.handlers.RotatingFileHandler(
        log_file,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8"
    )
    file_handler.setLevel(numeric_level)
    file_handler.setFormatter(detailed_formatter)
    root_logger.addHandler(file_handler)
    
    # Error file handler
    error_log_file = log_dir / "errors.log"
    error_handler = logging.handlers.RotatingFileHandler(
        error_log_file,
        maxBytes=max_bytes,
        backupCount=backup_count,
        encoding="utf-8"
    )
    error_handler.setLevel(logging.ERROR)
    error_handler.setFormatter(detailed_formatter)
    root_logger.addHandler(error_handler)
    
    # Log the setup completion
    logger = logging.getLogger(__name__)
    logger.info(f"Logging setup completed. Log level: {log_level}, Log directory: {log_dir}")

class BotLogger:
    """Enhanced logger class for the Smart Trading Bot."""
    
    def __init__(self, name: str):
        self.logger = logging.getLogger(name)
    
    def info(self, message: str, **kwargs):
        self.logger.info(message, extra=kwargs)

    def warning(self, message: str, **kwargs):
        self.logger.warning(message, extra=kwargs)

    def error(self, message: str, exc_info=False, **kwargs):
        self.logger.error(message, exc_info=exc_info, extra=kwargs)

    def debug(self, message: str, **kwargs):
        self.logger.debug(message, extra=kwargs)

    def critical(self, message: str, **kwargs):
        self.logger.critical(message, extra=kwargs)

    def log_trade_event(self, event_type: str, symbol: str, details: dict):
        self.logger.info(f"TRADE_EVENT: {event_type} | SYMBOL: {symbol} | DETAILS: {details}")

    def log_risk_event(self, event_type: str, details: dict):
        self.logger.warning(f"RISK_EVENT: {event_type} | DETAILS: {details}")

    def log_system_event(self, event_type: str, details: dict):
        self.logger.info(f"SYSTEM_EVENT: {event_type} | DETAILS: {details}")

    def log_ml_event(self, event_type: str, details: dict):
        self.logger.info(f"ML_EVENT: {event_type} | DETAILS: {details}")

    def log_error_with_context(self, error: Exception, context: dict):
        context_str = " | ".join([f"{k}={v}" for k, v in context.items()])
        self.logger.error(f"ERROR: {str(error)} | CONTEXT: {context_str}", exc_info=True)

