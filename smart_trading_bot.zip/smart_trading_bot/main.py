"""
Smart Trading Bot - Main Entry Point
Bot AI Trading Otomatis dengan SMC/ICT Analysis

Author: Mulky Malikul Dhaher
"""

import sys
import os
import asyncio
import logging
from pathlib import Path

# Add project root to Python path
project_root = Path(__file__).parent
sys.path.insert(0, str(project_root))

from core.trading_engine import TradingEngine
from core.config_manager import ConfigManager
from core.logger_setup import setup_logging

async def main():
    """Main entry point for Smart Trading Bot."""
    try:
        # Setup logging
        setup_logging()
        logger = logging.getLogger(__name__)
        
        logger.info("🚀 Starting Smart Trading Bot...")
        logger.info("=" * 50)
        
        # Load configuration
        config_manager = ConfigManager()
        config = await config_manager.load_config()
        
        # Initialize trading engine
        trading_engine = TradingEngine(config)
        
        # Start the bot
        await trading_engine.start()
        
    except KeyboardInterrupt:
        logger.info("Bot dihentikan oleh user.")
    except Exception as e:
        logger.error(f"Fatal error: {e}", exc_info=True)
        sys.exit(1)

if __name__ == "__main__":
    asyncio.run(main())

