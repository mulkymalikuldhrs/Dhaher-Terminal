"""
Smart Trading Bot - Advanced Risk Manager
Implements advanced risk management features including correlation analysis,
drawdown protection, and portfolio heat management.
"""

import asyncio
import logging
import pandas as pd
import numpy as np
from typing import Dict, Any, List, Optional
from datetime import datetime, timedelta

from core.logger_setup import BotLogger

class AdvancedRiskManager:
    """Advanced risk management with correlation analysis and portfolio heat management."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = BotLogger(__name__)
        self.risk_config = config["risk_management"]
        
        # Risk tracking
        self.daily_pnl = 0.0
        self.weekly_pnl = 0.0
        self.monthly_pnl = 0.0
        self.max_drawdown = 0.0
        self.peak_equity = 0.0
        
        # Position tracking
        self.open_positions = {}
        self.correlation_matrix = {}
        
        self.logger.info("Advanced Risk Manager initialized.")

    async def assess_portfolio_risk(self, proposed_trades: List[Dict[str, Any]], 
                                    current_positions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Assesses overall portfolio risk including correlation and heat."""
        risk_assessment = {
            "approved_trades": [],
            "rejected_trades": [],
            "portfolio_heat": 0.0,
            "correlation_risk": 0.0,
            "risk_warnings": []
        }
        
        # Calculate current portfolio heat
        current_heat = await self._calculate_portfolio_heat(current_positions)
        risk_assessment["portfolio_heat"] = current_heat
        
        # Check correlation risk
        correlation_risk = await self._assess_correlation_risk(proposed_trades, current_positions)
        risk_assessment["correlation_risk"] = correlation_risk
        
        # Evaluate each proposed trade
        for trade in proposed_trades:
            trade_assessment = await self._assess_single_trade_risk(trade, current_positions)
            
            if trade_assessment["approved"]:
                risk_assessment["approved_trades"].append(trade)
            else:
                risk_assessment["rejected_trades"].append({
                    "trade": trade,
                    "rejection_reason": trade_assessment["reason"]
                })
                risk_assessment["risk_warnings"].append(trade_assessment["reason"])
        
        self.logger.info("Portfolio risk assessment completed.", assessment=risk_assessment)
        return risk_assessment

    async def _calculate_portfolio_heat(self, positions: List[Dict[str, Any]]) -> float:
        """Calculates current portfolio heat (total risk exposure)."""
        total_risk = 0.0
        
        for position in positions:
            # Calculate risk for each position
            position_risk = position.get("risk_amount", 0.0)
            total_risk += position_risk
        
        # Convert to percentage of account
        account_balance = 10000.0  # Mock account balance
        portfolio_heat = (total_risk / account_balance) * 100
        
        self.logger.debug(f"Portfolio heat calculated: {portfolio_heat:.2f}%")
        return portfolio_heat

    async def _assess_correlation_risk(self, proposed_trades: List[Dict[str, Any]], 
                                       current_positions: List[Dict[str, Any]]) -> float:
        """Assesses correlation risk between proposed trades and current positions."""
        if not proposed_trades or not current_positions:
            return 0.0
        
        # Mock correlation matrix (in real implementation, this would be calculated from historical data)
        correlation_pairs = {
            ("EURUSD", "GBPUSD"): 0.7,
            ("EURUSD", "XAUUSD"): -0.3,
            ("GBPUSD", "XAUUSD"): -0.2,
            ("EURUSD", "USDJPY"): -0.6,
            ("GBPUSD", "USDJPY"): -0.5
        }
        
        max_correlation = 0.0
        
        for trade in proposed_trades:
            trade_symbol = trade["symbol"]
            
            for position in current_positions:
                position_symbol = position.get("symbol", "")
                
                # Check correlation
                pair_key = tuple(sorted([trade_symbol, position_symbol]))
                correlation = correlation_pairs.get(pair_key, 0.0)
                
                # If same direction and high correlation, increase risk
                if (trade["direction"] == position.get("direction", "") and 
                    abs(correlation) > 0.6):
                    max_correlation = max(max_correlation, abs(correlation))
        
        self.logger.debug(f"Maximum correlation risk: {max_correlation:.2f}")
        return max_correlation

    async def _assess_single_trade_risk(self, trade: Dict[str, Any], 
                                        current_positions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Assesses risk for a single trade."""
        assessment = {
            "approved": True,
            "reason": "",
            "risk_score": 0.0
        }
        
        # Check daily loss limit
        if await self._check_daily_loss_limit():
            assessment["approved"] = False
            assessment["reason"] = "Daily loss limit reached"
            return assessment
        
        # Check maximum open positions
        max_positions = self.risk_config.get("max_open_trades", 5)
        if len(current_positions) >= max_positions:
            assessment["approved"] = False
            assessment["reason"] = f"Maximum open positions ({max_positions}) reached"
            return assessment
        
        # Check portfolio heat limit
        current_heat = await self._calculate_portfolio_heat(current_positions)
        trade_risk_percent = trade.get("risk_percent", 1.0)
        
        if current_heat + trade_risk_percent > 10.0:  # Max 10% portfolio heat
            assessment["approved"] = False
            assessment["reason"] = f"Portfolio heat limit exceeded ({current_heat + trade_risk_percent:.1f}% > 10.0%)"
            return assessment
        
        # Check minimum RR ratio
        min_rr = self.risk_config.get("min_rr_ratio", 3.0)
        trade_rr = trade.get("risk_reward_ratio", 0.0)
        
        if trade_rr < min_rr:
            assessment["approved"] = False
            assessment["reason"] = f"Risk-reward ratio too low ({trade_rr:.1f} < {min_rr})"
            return assessment
        
        # Calculate risk score
        risk_factors = [
            current_heat / 10.0,  # Portfolio heat factor
            max(0, (max_positions - len(current_positions)) / max_positions),  # Position capacity factor
            max(0, (trade_rr - min_rr) / min_rr)  # RR ratio factor
        ]
        assessment["risk_score"] = np.mean(risk_factors)
        
        self.logger.debug(f"Trade risk assessment: {assessment}")
        return assessment

    async def _check_daily_loss_limit(self) -> bool:
        """Checks if daily loss limit has been reached."""
        max_daily_loss_percent = self.risk_config.get("max_daily_loss_percent", 4.0)
        account_balance = 10000.0  # Mock account balance
        max_daily_loss = account_balance * (max_daily_loss_percent / 100)
        
        return abs(self.daily_pnl) >= max_daily_loss

    async def update_pnl(self, trade_pnl: float):
        """Updates P&L tracking."""
        self.daily_pnl += trade_pnl
        self.weekly_pnl += trade_pnl
        self.monthly_pnl += trade_pnl
        
        # Update drawdown tracking
        current_equity = 10000.0 + self.daily_pnl  # Mock calculation
        if current_equity > self.peak_equity:
            self.peak_equity = current_equity
        
        current_drawdown = (self.peak_equity - current_equity) / self.peak_equity * 100
        if current_drawdown > self.max_drawdown:
            self.max_drawdown = current_drawdown
        
        self.logger.info(f"P&L updated: Daily={self.daily_pnl:.2f}, Drawdown={current_drawdown:.2f}%")

    async def reset_daily_pnl(self):
        """Resets daily P&L (should be called at start of new trading day)."""
        self.daily_pnl = 0.0
        self.logger.info("Daily P&L reset.")

    async def get_risk_metrics(self) -> Dict[str, Any]:
        """Returns current risk metrics."""
        account_balance = 10000.0  # Mock account balance
        current_equity = account_balance + self.daily_pnl
        current_drawdown = (self.peak_equity - current_equity) / self.peak_equity * 100 if self.peak_equity > 0 else 0.0
        
        return {
            "daily_pnl": self.daily_pnl,
            "weekly_pnl": self.weekly_pnl,
            "monthly_pnl": self.monthly_pnl,
            "current_drawdown": current_drawdown,
            "max_drawdown": self.max_drawdown,
            "account_balance": account_balance,
            "current_equity": current_equity,
            "daily_loss_limit_reached": await self._check_daily_loss_limit()
        }

