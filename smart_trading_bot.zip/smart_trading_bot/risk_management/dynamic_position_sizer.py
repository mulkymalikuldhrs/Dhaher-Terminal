"""
Smart Trading Bot - Dynamic Position Sizing
Calculates position size dynamically based on risk, volatility, and confidence.
"""

import logging
from typing import Dict, Any

from core.logger_setup import BotLogger

class DynamicPositionSizer:
    """Calculates dynamic position size for trades."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = BotLogger(__name__)
        self.risk_config = config["risk_management"]
        
        self.logger.info("Dynamic Position Sizer initialized.")

    async def calculate_position_size(self, 
                                      account_balance: float, 
                                      risk_per_trade_percent: float, 
                                      stop_loss_pips: float, 
                                      pip_value: float, 
                                      confidence_score: float = 1.0) -> float:
        """Calculates dynamic position size.
        
        Args:
            account_balance (float): Current account balance.
            risk_per_trade_percent (float): Percentage of account to risk per trade.
            stop_loss_pips (float): Stop loss distance in pips.
            pip_value (float): Value of one pip for the trading instrument.
            confidence_score (float): Confidence score of the trade signal (0.0 to 1.0).
            
        Returns:
            float: Calculated position size in lots.
        """
        
        if stop_loss_pips <= 0 or pip_value <= 0:
            self.logger.warning("Invalid stop loss pips or pip value. Cannot calculate position size.")
            return 0.0

        # Calculate risk amount in currency
        risk_amount = account_balance * (risk_per_trade_percent / 100)
        
        # Adjust risk based on confidence (e.g., lower confidence = lower risk amount)
        adjusted_risk_amount = risk_amount * confidence_score
        
        # Calculate position size in units/lots
        # For Forex, Position Size = (Risk Amount / (Stop Loss in Pips * Pip Value per Lot))
        # Assuming pip_value is already per lot
        position_size_units = adjusted_risk_amount / (stop_loss_pips * pip_value)
        
        # Convert to standard lot sizes if necessary (e.g., round to 0.01 for micro lots)
        # This depends on broker requirements
        position_size_lots = round(position_size_units, 2) # Example rounding
        
        self.logger.info(f"Calculated position size: {position_size_lots} lots (Risk: {risk_per_trade_percent}%, SL: {stop_loss_pips} pips, Confidence: {confidence_score})")
        
        return position_size_lots

    async def calculate_volatility_adjusted_sl(self, current_price: float, atr_value: float, multiplier: float = 1.5) -> float:
        """Calculates volatility-adjusted stop loss based on ATR.
        
        Args:
            current_price (float): Current market price.
            atr_value (float): Average True Range value.
            multiplier (float): Multiplier for ATR.
            
        Returns:
            float: Stop loss distance in pips.
        """
        # This assumes ATR is in price units. Convert to pips if needed.
        # For example, if ATR is 0.0050 for EURUSD, and 1 pip is 0.0001, then 50 pips.
        
        stop_loss_distance = atr_value * multiplier
        self.logger.info(f"Volatility-adjusted SL distance: {stop_loss_distance} (ATR: {atr_value}, Multiplier: {multiplier})")
        return stop_loss_distance


