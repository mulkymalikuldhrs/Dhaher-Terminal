"""
Smart Trading Bot - Risk Manager
Manages risk and money management according to the trading plan.
"""

from core.logger_setup import BotLogger
from risk_management.dynamic_position_sizer import DynamicPositionSizer
from risk_management.advanced_risk_manager import AdvancedRiskManager

class RiskManager:
    """Manages risk and money management for trading operations."""
    
    def __init__(self, config: Dict[str, Any]):
        self.config = config
        self.logger = BotLogger(__name__)
        self.risk_config = config["risk_management"]
        self.position_sizer = DynamicPositionSizer(config)
        self.advanced_risk_manager = AdvancedRiskManager(config)
        
        self.logger.info("Risk Manager initialized.")

    async def assess_and_signal(self, smc_ict_analysis: Dict[str, Any], ml_predictions: Dict[str, Any], 
                                current_positions: List[Dict[str, Any]] = None) -> List[Dict[str, Any]]:
        """Assesses risk and generates trade signals based on analysis and predictions."""
        if current_positions is None:
            current_positions = []
        
        # Generate preliminary trade signals
        preliminary_signals = await self._generate_preliminary_signals(smc_ict_analysis, ml_predictions)
        
        # Assess portfolio risk for all signals
        risk_assessment = await self.advanced_risk_manager.assess_portfolio_risk(
            preliminary_signals, current_positions
        )
        
        # Apply dynamic position sizing to approved trades
        approved_signals = []
        for signal in risk_assessment["approved_trades"]:
            # Mock values for account_balance, stop_loss_pips, pip_value
            account_balance = 10000.0 
            stop_loss_pips = 20.0 
            pip_value = 10.0 
            
            signal["position_size"] = await self.position_sizer.calculate_position_size(
                account_balance,
                signal["risk_percent"],
                stop_loss_pips,
                pip_value,
                signal["confidence"]
            )
            
            # Calculate risk-reward ratio
            signal["risk_reward_ratio"] = self._calculate_rr_ratio(signal)
            
            approved_signals.append(signal)
            self.logger.info(f"Approved signal for {signal['symbol']}: {signal['direction']} with position size {signal['position_size']}")

        # Log rejected trades
        for rejected in risk_assessment["rejected_trades"]:
            self.logger.warning(f"Rejected trade for {rejected['trade']['symbol']}: {rejected['rejection_reason']}")

        self.logger.info("Risk assessment and signal generation completed.")
        return approved_signals

    async def _generate_preliminary_signals(self, smc_ict_analysis: Dict[str, Any], 
                                            ml_predictions: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Generates preliminary trade signals before risk assessment."""
        trade_signals = []
        
        # Example: Simple signal generation based on SMC/ICT analysis
        overall_bias = smc_ict_analysis.get("overall_bias", "")
        
        if overall_bias == "Bullish":
            # Check for bullish entry conditions based on POI, liquidity, etc.
            signal = {
                "symbol": self.config["trading"]["pairs"][0], # Use first configured pair
                "direction": "BUY",
                "entry_price": 1.1000, # Mock entry price
                "stop_loss": 1.0950, # Mock stop loss
                "take_profit": 1.1150, # Mock take profit
                "risk_percent": self.risk_config["risk_per_trade_percent"],
                "confidence": ml_predictions.get(self.config["trading"]["timeframes"]["LTF"], {}).get("confidence", 0.7)
            }
            trade_signals.append(signal)
            self.logger.info("Generated BUY signal (preliminary).")
            
        elif overall_bias == "Bearish":
            # Check for bearish entry conditions
            signal = {
                "symbol": self.config["trading"]["pairs"][0],
                "direction": "SELL",
                "entry_price": 1.1000, # Mock entry price
                "stop_loss": 1.1050, # Mock stop loss
                "take_profit": 1.0850, # Mock take profit
                "risk_percent": self.risk_config["risk_per_trade_percent"],
                "confidence": ml_predictions.get(self.config["trading"]["timeframes"]["LTF"], {}).get("confidence", 0.7)
            }
            trade_signals.append(signal)
            self.logger.info("Generated SELL signal (preliminary).")
        
        return trade_signals

    def _calculate_rr_ratio(self, signal: Dict[str, Any]) -> float:
        """Calculates risk-reward ratio for a signal."""
        entry = signal.get("entry_price", 0)
        stop_loss = signal.get("stop_loss", 0)
        take_profit = signal.get("take_profit", 0)
        
        if entry == 0 or stop_loss == 0 or take_profit == 0:
            return 0.0
        
        risk = abs(entry - stop_loss)
        reward = abs(take_profit - entry)
        
        if risk == 0:
            return 0.0
        
        return reward / risk

    async def update_trade_pnl(self, trade_pnl: float):
        """Updates P&L tracking."""
        await self.advanced_risk_manager.update_pnl(trade_pnl)

    async def get_risk_metrics(self) -> Dict[str, Any]:
        """Returns current risk metrics."""
        return await self.advanced_risk_manager.get_risk_metrics()

    async def check_daily_loss_limit(self, current_daily_loss: float) -> bool:
        """Checks if the daily loss limit has been reached."""
        return await self.advanced_risk_manager._check_daily_loss_limit()


